@ALTER TABLE wcf1_tag ADD UNIQUE KEY (languageID, name);
@ALTER TABLE wcf1_tag_to_object DROP PRIMARY KEY;
@ALTER TABLE wcf1_tag_to_object ADD PRIMARY KEY (taggableID, languageID, objectID, tagID);
ALTER TABLE wcf1_tag_to_object ADD KEY (taggableID, languageID, tagID);
ALTER TABLE wcf1_tag_to_object ADD KEY (tagID, taggableID);