/* bbcodes */
DROP TABLE IF EXISTS wcf1_bbcode;
CREATE TABLE wcf1_bbcode (
	bbcodeID int(10) unsigned NOT NULL auto_increment,
	bbcodeTag varchar(255) NOT NULL default '',
	packageID int(10) unsigned NOT NULL default 0,
	htmlOpen varchar(255) NOT NULL default '',
	htmlClose varchar(255) NOT NULL default '',
	textOpen varchar(255) NOT NULL default '',
	textClose varchar(255) NOT NULL default '',
	allowedChildren varchar(255) NOT NULL default 'all',
	className varchar(255) NOT NULL default '',
	wysiwyg tinyint(1) NOT NULL default 0,
	wysiwygIcon varchar(255) NOT NULL default '',
	sourceCode tinyint(1) NOT NULL default 0,
	disabled tinyint(1) unsigned NOT NULL default 0,
	PRIMARY KEY (bbcodeID),
	UNIQUE KEY (bbcodeTag)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS wcf1_bbcode_attribute;
CREATE TABLE wcf1_bbcode_attribute (
	bbcodeID int(10) unsigned NOT NULL default 0,
	attributeNo int(10) unsigned NOT NULL default 0,
	attributeHtml varchar(255) NOT NULL default '',
	attributeText varchar(255) NOT NULL default '',
	validationPattern varchar(255) NOT NULL default '',
	required tinyint(1) unsigned NOT NULL default 0,
	useText tinyint(1) unsigned NOT NULL default 0,
	PRIMARY KEY (bbcodeID, attributeNo)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/* smilies */		
DROP TABLE IF EXISTS wcf1_smiley;
CREATE TABLE wcf1_smiley (
	smileyID INT(10) NOT NULL AUTO_INCREMENT PRIMARY KEY,
	packageID INT(10) NOT NULL DEFAULT 0,
	smileyCategoryID INT(10) NOT NULL DEFAULT 0,
	smileyPath VARCHAR(255) NOT NULL DEFAULT '',
	smileyTitle VARCHAR(255) NOT NULL DEFAULT '',
	smileyCode VARCHAR(255) NOT NULL DEFAULT '',
	showOrder MEDIUMINT(5) NOT NULL DEFAULT 0,
	KEY (smileyCategoryID)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS wcf1_smiley_category;
CREATE TABLE wcf1_smiley_category (
	smileyCategoryID INT(10) NOT NULL AUTO_INCREMENT PRIMARY KEY,
	title VARCHAR(255) NOT NULL DEFAULT '',
	showOrder MEDIUMINT(5) NOT NULL DEFAULT 0,
	disabled TINYINT(1) NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=utf8;