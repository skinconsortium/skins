-- user profile menu
DROP TABLE IF EXISTS wcf1_user_profile_menu_item;
CREATE TABLE wcf1_user_profile_menu_item (
  menuItemID int(10) unsigned NOT NULL auto_increment,
  packageID int(10) unsigned NOT NULL default '0',
  menuItem varchar(255) NOT NULL default '',
  parentMenuItem varchar(255) NOT NULL default '',
  menuItemLink varchar(255) NOT NULL default '',
  menuItemIcon varchar(255) NOT NULL default '',
  showOrder int(10) NOT NULL default '0',
  permissions text NULL,
  PRIMARY KEY (menuItemID),
  UNIQUE KEY (menuItem,packageID)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;