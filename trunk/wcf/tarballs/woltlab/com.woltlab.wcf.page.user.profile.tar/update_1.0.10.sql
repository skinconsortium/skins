-- alter tables
ALTER TABLE wcf1_user ADD KEY (activityPoints);
@ALTER TABLE wcf1_user ADD gravatar VARCHAR(255) NOT NULL DEFAULT '';
@ALTER TABLE wcf1_user ADD disableAvatarReason text NULL;
ALTER TABLE wcf1_user_blacklist ADD KEY (blackUserID);
@ALTER TABLE wcf1_user_whitelist ADD confirmed TINYINT(1) NOT NULL DEFAULT 0;
@ALTER TABLE wcf1_user_whitelist ADD notified TINYINT(1) NOT NULL DEFAULT 0;
@ALTER TABLE wcf1_user_whitelist ADD time INT(10) NOT NULL DEFAULT 0;
ALTER TABLE wcf1_user_whitelist ADD KEY (whiteUserID, confirmed);
ALTER TABLE wcf1_user_whitelist ADD KEY (userID, confirmed);
@ALTER TABLE wcf1_avatar ADD avatarCategoryID INT(10) NOT NULL DEFAULT 0;
ALTER TABLE wcf1_avatar ADD KEY (avatarCategoryID);
@ALTER TABLE wcf1_user_profile_menu_item ADD options TEXT NULL;

-- add new tables
DROP TABLE IF EXISTS wcf1_avatar_category;
CREATE TABLE wcf1_avatar_category (
	avatarCategoryID INT(10) NOT NULL AUTO_INCREMENT PRIMARY KEY,
	title VARCHAR(255) NOT NULL DEFAULT '',
	showOrder MEDIUMINT(5) NOT NULL DEFAULT 0,
	groupID INT(10) NOT NULL DEFAULT 0,
	neededPoints INT(10) NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS wcf1_user_profile_visitor;
CREATE TABLE wcf1_user_profile_visitor (
  ownerID INT(10) NOT NULL,
  userID INT(10) NOT NULL DEFAULT 0,
  time INT(10) NOT NULL DEFAULT 0,
  UNIQUE KEY (ownerID, userID),
  KEY (time)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- update friendships
DROP TABLE IF EXISTS wcf1_user_whitelist_tmp;
CREATE TEMPORARY TABLE wcf1_user_whitelist_tmp  (
	userID int(10) unsigned NOT NULL,
	whiteUserID int(10) unsigned NOT NULL,
	UNIQUE KEY (userID, whiteUserID)
) DEFAULT CHARSET=utf8;

INSERT INTO	wcf1_user_whitelist_tmp
SELECT		userID, whiteUserID
FROM		wcf1_user_whitelist;

UPDATE	wcf1_user_whitelist whitelist
SET		confirmed = 1
WHERE	(
			SELECT	userID
			FROM	wcf1_user_whitelist_tmp
			WHERE	userID = whitelist.whiteUserID
					AND whiteUserID = whitelist.userID
		) IS NOT NULL;
		
DROP TABLE IF EXISTS wcf1_user_whitelist_tmp;