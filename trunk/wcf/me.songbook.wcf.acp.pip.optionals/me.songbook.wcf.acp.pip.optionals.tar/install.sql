-- creates a dummy table so wcf is satisfied :P

CREATE TABLE wcf1_optionals_dummy (
	packageID int(11) UNSIGNED NOT NULL,
	PRIMARY KEY  (packageID)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8