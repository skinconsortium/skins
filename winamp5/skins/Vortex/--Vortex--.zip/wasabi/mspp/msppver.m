Function String neededMSPP_Version();

neededMSPP_Version()
{
	return "0.14";
}