#include "../../../lib/std.mi"
#include "attribs.m"

System.onScriptLoaded() {
	initAttribs();
}